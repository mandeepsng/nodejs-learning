---
title: Freelance Cockpit 2 - Project Management 
date: 2023-03-01T18:17:35.352Z
slug: freelance-cockpit-2-project-management
image: https://codelist.cc/uploads/posts/2015-10/1444375270_freelance-cockpit2.jpg
---


Dashboard Helpful overview of open projects, open invoices, received and outstanding payments, open tasks, messages and events. Project Management Create and manage all your projects. Project Tasks You can add tasks to any project. Support Tickets Let your Clients open tickets to keep track of any incident. It also supports email tickets. Project Timer This will help you to track the time you have spent on a project.Demo: http://codecanyon.net/item/freelance-cockpit-2-project-management/4203727
			

This file has UNTOUCHED status - (original developer code without any tampering done)
		

> [https://www.sendspace.com/file/aya9m2](https://www.sendspace.com/file/aya9m2)
> [https://userscloud.com/s6eel1pauleohttp://www.solidfiles.com/d/561b2eff63/http://rg.to/file/4c120bac40bdcc8c2f302e1a40503298/freelancecockpit.rar.htmlhttp://www.mediafire.com/download/2jem6r20el221cb/freelancecockpit.rar](https://userscloud.com/s6eel1pauleohttp://www.solidfiles.com/d/561b2eff63/http://rg.to/file/4c120bac40bdcc8c2f302e1a40503298/freelancecockpit.rar.htmlhttp://www.mediafire.com/download/2jem6r20el221cb/freelancecockpit.rar)
> [https://copy.com/TQHyynIFAtmcPABc](https://copy.com/TQHyynIFAtmcPABc)
