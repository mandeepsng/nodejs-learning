---
title: PlayBuzz and BoredPanda List Importer for Viralist 
date: 2023-03-01T18:16:50.288Z
slug: playbuzz-and-boredpanda-list-importer-for-viralist
image: https://codelist.cc/uploads/posts/2015-10/1444392733_playbuzz-viralist.jpg
---


“PlayBuzz and BoredPanda List Importer for Viralist” is an add-on and must have tool for anyone using “Viralist – Viral lists script with Facebook App” script.Demo: http://codecanyon.net/item/playbuzz-and-boredpanda-list-importer-for-viralist/13066013
			

This file has UNTOUCHED status - (original developer code without any tampering done)
		

> [https://www.sendspace.com/file/bawycy](https://www.sendspace.com/file/bawycy)
> [https://userscloud.com/3zzgluol6ycmhttp://www.solidfiles.com/d/beae30f2f5/http://rg.to/file/3c2b79cd157a3c9e5b3e942744476ef7/playbuzz10.rar.html](https://userscloud.com/3zzgluol6ycmhttp://www.solidfiles.com/d/beae30f2f5/http://rg.to/file/3c2b79cd157a3c9e5b3e942744476ef7/playbuzz10.rar.html)
> [https://copy.com/yuunKqXwtDlBVUwDhttp://downloads.ziddu.com/download/25026469/playbuzz10.rar.htmlhttp://www.mediafire.com/download/tve98k4v9x40p2o/playbuzz10.rar](https://copy.com/yuunKqXwtDlBVUwDhttp://downloads.ziddu.com/download/25026469/playbuzz10.rar.htmlhttp://www.mediafire.com/download/tve98k4v9x40p2o/playbuzz10.rar)
