---
title: opencart customer testimonial module 
date: 2023-03-01T18:17:45.267Z
slug: opencart-customer-testimonial-module
image: https://codelist.cc/uploads/posts/2015-10/1444375195_opencart-customer.jpg
---


Opencart Customer Testimonial Module” is the best module for give testimonial, feedback, comments, review of customer in an opencart website. Customer can view their testimonial after admin approve. Customer can also give ratings.Demo: http://codecanyon.net/item/opencart-customer-testimonial-module/5942252
			

This file has UNTOUCHED status - (original developer code without any tampering done)
		

> [https://www.sendspace.com/file/b2p4ia](https://www.sendspace.com/file/b2p4ia)
> [https://userscloud.com/3u6030fjmr84http://www.solidfiles.com/d/545191d1b7/http://rg.to/file/68d425327cec17501639550e74a734b7/opencartsustmod.rar.htmlhttp://www.mediafire.com/download/zb8og3h78r97kja/opencartsustmod.rar](https://userscloud.com/3u6030fjmr84http://www.solidfiles.com/d/545191d1b7/http://rg.to/file/68d425327cec17501639550e74a734b7/opencartsustmod.rar.htmlhttp://www.mediafire.com/download/zb8og3h78r97kja/opencartsustmod.rar)
> [https://copy.com/vcp4y2kYui2JzBAL](https://copy.com/vcp4y2kYui2JzBAL)
