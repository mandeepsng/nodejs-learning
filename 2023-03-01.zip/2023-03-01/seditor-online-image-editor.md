---
title: sEditor - online image editor 
date: 2023-03-01T18:16:55.287Z
slug: seditor-online-image-editor
image: https://codelist.cc/uploads/posts/2015-10/1444392739_seditor-image-editor.jpg
---


sEditor is build to replace need for Photoshop when you want to add some simple effects to your image. For instance, if you just want to pixelate or blur part of the image, or add a pointer/marker on a image, or add some text on it, or add a frame, or apply some effects similar to instagram, or just want to crop part of your image, or… then sEditor is perfect tool for you. Supported image formats are: jpg, jpeg Demo: http://codecanyon.net/item/seditor-online-image-editor/2770211
			

This file has UNTOUCHED status - (original developer code without any tampering done)
		

> [https://www.sendspace.com/file/kyr7f9](https://www.sendspace.com/file/kyr7f9)
> [https://userscloud.com/10f9i84klzmahttp://www.solidfiles.com/d/fe8163c2ba/http://rg.to/file/3cb15660e64a3cc34ed2c017140de7c8/seditor27.rar.html](https://userscloud.com/10f9i84klzmahttp://www.solidfiles.com/d/fe8163c2ba/http://rg.to/file/3cb15660e64a3cc34ed2c017140de7c8/seditor27.rar.html)
> [https://copy.com/pNCdZLJASQDdPWMHhttp://downloads.ziddu.com/download/25026468/seditor27.rar.htmlhttp://www.mediafire.com/download/o0oq0qk4dsqg33n/seditor27.rar](https://copy.com/pNCdZLJASQDdPWMHhttp://downloads.ziddu.com/download/25026468/seditor27.rar.htmlhttp://www.mediafire.com/download/o0oq0qk4dsqg33n/seditor27.rar)
