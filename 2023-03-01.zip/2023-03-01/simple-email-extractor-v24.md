---
title: Simple Email Extractor v2.4 
date: 2023-03-01T18:17:00.215Z
slug: simple-email-extractor-v24
image: https://codelist.cc/uploads/posts/2015-10/1444392670_simple-email-extractor.jpg
---


A simple software to extract email addresses from websites and social networks like Facebook, Twitter, LinkedIn, MySpace, ... Put your URLs sources in the file “Sources.txt”, at the root directory.Demo: http://codecanyon.net/item/simpleemailextractor/1130092
			

This file has UNTOUCHED status - (original developer code without any tampering done)
		

> [https://www.sendspace.com/file/4knvv6](https://www.sendspace.com/file/4knvv6)
> [https://userscloud.com/7r7lgoiu0onfhttp://www.solidfiles.com/d/eb4067536b/http://rg.to/file/646d4ecb6c54e6adfd7d4994b542229d/simpleemailextractor24.rar.html](https://userscloud.com/7r7lgoiu0onfhttp://www.solidfiles.com/d/eb4067536b/http://rg.to/file/646d4ecb6c54e6adfd7d4994b542229d/simpleemailextractor24.rar.html)
> [https://copy.com/THk3rZQfskqfGrDThttp://downloads.ziddu.com/download/25026467/simpleemailextractor24.rar.htmlhttp://www.mediafire.com/download/mn3lvycig6wu0z7/simpleemailextractor24.rar](https://copy.com/THk3rZQfskqfGrDThttp://downloads.ziddu.com/download/25026467/simpleemailextractor24.rar.htmlhttp://www.mediafire.com/download/mn3lvycig6wu0z7/simpleemailextractor24.rar)
