---
title: Akismet Spam Killer for Magento 
date: 2023-03-01T18:17:10.282Z
slug: akismet-spam-killer-for-magento
image: https://codelist.cc/uploads/posts/2015-10/1444375411_akismet-spam-killer-magento.jpg
---


Magento spam killer without CAPTCHA! We know it cost you a lot time to delete the daily received spam through the contact and product review form. With our magento Akismet (Automattic Kismet (Akismet for short)) extension for magento no installation of CAPTHA is needed. A CAPTHA is not very user friendly and statics have shown that it can be cracked.Demo: http://codecanyon.net/item/akismet-spam-killer-for-magento/2642353
			

This file has UNTOUCHED status - (original developer code without any tampering done)
		

> [https://www.sendspace.com/file/z4u036](https://www.sendspace.com/file/z4u036)
> [https://userscloud.com/e553iag65qgjhttp://www.solidfiles.com/d/a0a146dd35/http://rg.to/file/ec9cff1c9ba20d07da54a0cc88a28da2/akismetspamkillermagento.rar.html](https://userscloud.com/e553iag65qgjhttp://www.solidfiles.com/d/a0a146dd35/http://rg.to/file/ec9cff1c9ba20d07da54a0cc88a28da2/akismetspamkillermagento.rar.html)
> [https://copy.com/fwxVqhY6KP2iSAlW](https://copy.com/fwxVqhY6KP2iSAlW)
